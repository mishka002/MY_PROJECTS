function registeruser() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    localStorage.setItem("email", email);
    localStorage.setItem("password", password);
    
    location.replace("http://127.0.0.1:5500/success.html");


    
    

}

